<?php

$conn = mysqli_connect('localhost','root','','ecomm_clone') or die('connection failed');

?>